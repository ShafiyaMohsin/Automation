package Program;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Register {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\admin\\Documents\\AutomationTesting\\Browser_Extension\\\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();

		//URL
		driver.get("https://parabank.parasoft.com/parabank/register.htm");
		//maximize
		driver.manage().window().maximize();
		
		Thread.sleep(2000);
		//Registration
		driver.findElement(By.linkText("Register")).click();	
		Thread.sleep(3000);
		//FirstName
		driver.findElement(By.xpath("//input[@name='customer.firstName']")).sendKeys("john");
		Thread.sleep(3000);
		//LastName
		driver.findElement(By.xpath("//input[@name='customer.lastName']")).sendKeys("Smith");
		Thread.sleep(3000);
		//Addresss
		driver.findElement(By.xpath("//input[@name='customer.address.street']")).sendKeys("1431 Main St");
		Thread.sleep(3000);
		
		
//city.
		
		driver.findElement(By.xpath("//input[@name='customer.address.city']")).sendKeys("Beverly Hills");
		Thread.sleep(3000);
		//state
		driver.findElement(By.xpath("//input[@name='customer.address.state']")).sendKeys("CA");
		Thread.sleep(3000);
		//zipcode
		driver.findElement(By.xpath("//input[@name='customer.address.zipCode']")).sendKeys("90210");
		Thread.sleep(3000);
		//phone
		driver.findElement(By.xpath("//input[@name='customer.phoneNumber']")).sendKeys("310-447-4121");
		Thread.sleep(3000);
		//SSN
		driver.findElement(By.xpath("//input[@name='customer.ssn']")).sendKeys("123456789");
		Thread.sleep(3000);
		//Username
		driver.findElement(By.xpath("//input[@name='customer.username']")).sendKeys("john");
		Thread.sleep(3000);
		//password
				driver.findElement(By.xpath("//input[@name='customer.password']")).sendKeys("demo");
				Thread.sleep(3000);
				
				//confirmPassword
				driver.findElement(By.xpath("//input[@name='repeatedPassword']")).sendKeys("demo");
				Thread.sleep(3000);
				
				driver.findElement(By.xpath("//input[@class='button']")).click();
				Thread.sleep(3000);
				 driver.close();

				

	}

}
