package Program;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.google.common.io.Files;

public class Screenshot_Scrolling {

	public static void main(String[] args) throws InterruptedException, IOException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\admin\\Documents\\AutomationTesting\\Browser_Extension\\chromedriver.exe");
		WebDriver driver =new ChromeDriver();
		Pom obj=new Pom();
		obj.url(driver);
		Thread.sleep(2000);
		obj.maximizeBrowser(driver);
		Thread.sleep(2000);
		driver.findElement(By.linkText("Contact Us")).click();
		Thread.sleep(2000);
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("window.scrollTo(0,document.body.scrollHeight)");
		Thread.sleep(2000);
		js.executeScript("window.scrollTo(0,-document.body.scrollHeight)");
		
		//obj.closeBrowser(driver);
		//TakesScreenshot ts =(TakesScreenshot)driver;
		//File src = ts.getScreenshotAs(OutputType.FILE);
		//File des= new File ("./para.jpg");
		//FileUtils.copyFile(src, des);
		//File f=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			
		// Files.copy(f,new File("C:\\Users\\admin\\Documents\\autoamation\\automation backup\\Individual_Project\\Screenshot.jpg"));
		TakesScreenshot ss=(TakesScreenshot) driver;
		File src=ss.getScreenshotAs(OutputType.FILE);
		File des= new File("./screenshot.png");
		File des1= new File("./screenshot.png");
		FileUtils.copyFileToDirectory(src, des);
		FileUtils.copyFileToDirectory(src, des1);
		Thread.sleep(2000);
		 driver.close();
		 

	}

}
