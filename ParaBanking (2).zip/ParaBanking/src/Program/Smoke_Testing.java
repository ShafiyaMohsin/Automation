package Program;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Smoke_Testing {

	public static void main(String[] args) throws InterruptedException, Exception {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\admin\\Documents\\AutomationTesting\\Browser_Extension\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();

		//URL
		driver.get("https://parabank.parasoft.com/parabank/register.htm");
		//maximize
		driver.manage().window().maximize();
		
		Thread.sleep(2000);
		
		//enter the name
		driver.findElement(By.xpath("//input[@name='username']")).sendKeys("john");
		//password
		
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys("demo");
		//submit
		driver.findElement(By.xpath("//*[@id='loginPanel']/form/div[3]/input")).click();
		
	//	driver.findElement(By.xpath("//a[@href='/parabank/logout.htm']")).click();

		
		//validation title
		String expected ="ParaBank | Accounts Overview";
				String actual = driver.getTitle();
				
				if(expected.equals(actual)) {
					System.out.println("Login Successfull");
					
				}else {
					System.out.println("Login Failed");
				}
				
				 
				TakesScreenshot ss=(TakesScreenshot) driver;
					File src=ss.getScreenshotAs(OutputType.FILE);
					File des= new File("./ParaBanksmokes.png");
					File des1= new File("./ParaBanksucceful.png");
					FileUtils.copyFileToDirectory(src, des);
					FileUtils.copyFileToDirectory(src, des1);
					Thread.sleep(2000);
					 driver.close();
					 


	}

}
