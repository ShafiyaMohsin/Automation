package POM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Login {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	
	public void url(WebDriver driver) {
		driver.get("https://parabank.parasoft.com/parabank/register.htm");
	}
	public void maximizeBrowser(WebDriver driver) {
		driver.manage().window().maximize();
	}
	//usn
	public void enterUsername(WebDriver driver,String usn) {
		driver.findElement(By.xpath("//input[@name='username']")).sendKeys(usn);
	}
	//pwd
	public void enterPassword(WebDriver driver,String pwd) {
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys(pwd);
	}
	public void clickOnLoginButton(WebDriver driver) {
		driver.findElement(By.xpath("//input[@type='submit']")).click();
	}
	public void clickOnLogOutButton(WebDriver driver) {
		driver.findElement(By.xpath("//a[@href='/parabank/logout.htm']")).click();

		
	}
	

	public void closeBrowser(WebDriver driver) {
		driver.close();
		

}}
