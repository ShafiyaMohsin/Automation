package hybrid;

import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;

import Framework.Operational;

public class Hy_ReadExcel {

	
		public void readExcel(WebDriver driver) throws Exception
		{
			
			FileInputStream file = new FileInputStream("C:\\Users\\admin\\Documents\\AutomationTesting\\POI\\POII.xlsx");
			XSSFWorkbook w = new XSSFWorkbook(file);
			XSSFSheet s= w.getSheet("Sheet1");
			int rowsize=s.getLastRowNum();
			System.out.println("No of Rows:" + rowsize);
			HybridOperational o=new HybridOperational();
			for (int i=1; i<=rowsize;i++)
			{
				String username=s.getRow(i).getCell(1).getStringCellValue();
				String password= s.getRow(i).getCell(2).getStringCellValue();
				System.out.println(username+"\t\t"+password);
				try
				{
					for(int j=1; j<=rowsize; j++) 
					{
						String key =s.getRow(j).getCell(0).getStringCellValue();
						if(key.equals("MaximizeBrowser"))
						{
							o.maximizeBrowser(driver);
							System.out.println(key);
							Thread.sleep(2000);
						}
						else if(key.equals("URL"))
						{
							o.url(driver);
							System.out.println(key);
							Thread.sleep(2000);
						}
						else if(key.equals("Username"))
						{
							o.enterUsername(driver, username);
							System.out.println(key);
							Thread.sleep(2000);
						}
						else if(key.equals("Password"))
						{
							o.enterPassword(driver, password);
							System.out.println(key);
							Thread.sleep(2000);
						}
						else if(key.equals("Login"))
						{
							o.clickOnLoginButton(driver);
							System.out.println(key);
							Thread.sleep(2000);
						}
						
						else if(key.equals("Logout"))
						{
							o.clickOnLogOutButton(driver);
							System.out.println(key);
							
							Thread.sleep(2000);
						}
						
						
					}
					System.out.println("Valid Credentials");
					System.out.println("");
					s.getRow(i).createCell(3).setCellValue("Valid Credentials.");
				}
				catch(Exception e)
				{
					System.out.println("Invalid Credentials");
					System.out.println("");
					s.getRow(i).createCell(3).setCellValue("Invalid Credentials.");
				}
			}
			FileOutputStream out= new FileOutputStream("C:\\Users\\admin\\Documents\\AutomationTesting\\POI\\POII.xlsx");
			w.write(out);
			o.closeBrowser(driver);
	}

}
