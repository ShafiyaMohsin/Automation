package Framework;

import org.testng.annotations.Test;

import Program.Pom;

import org.testng.annotations.DataProvider;
import org.testng.annotations.BeforeTest;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class DdtUsinTestNG {
	WebDriver driver;


	@BeforeTest
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\admin\\Documents\\AutomationTesting\\Browser_Extension\\chromedriver.exe");
		driver=new ChromeDriver();
		//maximize
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();


	}
	@Test(dataProvider = "dp")
	public void ddt(String usn, String pwd) throws InterruptedException {
		Pom obj=new Pom();
		obj.url(driver);
		Thread.sleep(2000);

		obj.maximizeBrowser(driver);
		obj.enterUsername(driver, usn);
		Thread.sleep(2000);

		obj.enterPassword(driver, pwd);
		Thread.sleep(2000);

		obj.clickOnLoginButton(driver);
		Thread.sleep(2000);

		obj.clickOnLogOutButton1(driver);



	}

	@DataProvider
	public Object[][] dp()
	
	{
		return new Object[][] 
				{
			new Object[] { "john", "demo" },
			new Object[] { "siya", "riya" },

			new Object[] { "ggf", "b" },
			new Object[] { "johnn", "demo" },
			

			new Object[] { "jhy", "yyy" },

			new Object[] { "jo", "demo" },

				};
	}


	@AfterTest
	public void afterTest() {
		driver.close();  

	}

}
