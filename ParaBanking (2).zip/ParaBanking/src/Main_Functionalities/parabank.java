package Main_Functionalities;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;

import java.io.File;

import javax.swing.JOptionPane;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;

public class parabank {
	WebDriver driver;
	@BeforeTest
	  public void beforeTest() {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\admin\\Documents\\AutomationTesting\\Browser_Extension\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.get("https://parabank.parasoft.com/");}
		
		
		 
		 
		 
		 
		 
		 
		 
		 @Test
		  public void ParaBank() throws Exception
		 {
			 driver.findElement(By.xpath("/html/body/div[1]/div[3]/div[1]/div/p[2]/a")).click();
				Thread.sleep(2000);
				driver.findElement(By.id("customer.firstName")).sendKeys("anna");
				Thread.sleep(2000);
		     driver.findElement(By.id("customer.lastName")).sendKeys("Smith");
				Thread.sleep(2000);
		     driver.findElement(By.id("customer.address.street")).sendKeys("1431 Main St");
				Thread.sleep(2000);
				driver.findElement(By.id("customer.address.city")).sendKeys("Beverly Hills");
				Thread.sleep(2000);
		     driver.findElement(By.id("customer.address.state")).sendKeys("CA");
				Thread.sleep(2000);
		     driver.findElement(By.id("customer.address.zipCode")).sendKeys("90210");
				Thread.sleep(2000);
		     driver.findElement(By.id("customer.phoneNumber")).sendKeys("310-447-4121");
				Thread.sleep(2000);
		     driver.findElement(By.id("customer.ssn")).sendKeys("123456789");
				Thread.sleep(2000);
				
				//Thread.sleep(2000);
			     driver.findElement(By.id("customer.username")).sendKeys("anna");
			     Thread.sleep(2000);
			     driver.findElement(By.id("customer.password")).sendKeys("demo11");
			     Thread.sleep(2000);
			     driver.findElement(By.id("repeatedPassword")).sendKeys("demo11");
			     //driver.findElement(By.xpath("//[@type=\"submit\"]")).click();
			     
			     driver.findElement(By.xpath("//input[@value='Register']")).click();
					}
		 @Test()
			 
			 @AfterTest
			  public void afterTest() throws Exception{
				 String usn=JOptionPane.showInputDialog("Enter Username");
					driver.findElement(By.xpath("//input[@name='username']")).sendKeys("john");
					Thread.sleep(2000);
					String pwd=JOptionPane.showInputDialog("Enter Password");
					driver.findElement(By.xpath("//input[@name='password']")).sendKeys("demo");
					Thread.sleep(2000);
					driver.findElement(By.xpath("//input[@class='button']")).click();
					Thread.sleep(2000);
				
				  
				  
				   driver.findElement(By.xpath("//*[@id=\"leftPanel\"]/ul/li[1]/a")).click();
				   Thread.sleep(2000);
				  Select d=new Select(driver.findElement(By.xpath("/html/body/div[1]/div[3]/div[2]/div/div/form/select[1]")));
					 d.selectByIndex(1); 
					 Thread.sleep(2000);
					 Select s=new Select(driver.findElement(By.xpath("/html/body/div[1]/div[3]/div[2]/div/div/form/select[2]")));
					 s.selectByIndex(3); 
					 
					 
					 driver.findElement(By.xpath("/html/body/div[1]/div[3]/div[2]/div/div/form/div/input")).click();
					 
					 s.selectByIndex(3);
					 Thread.sleep(2000);
			   
					 
					 
					TakesScreenshot ss=(TakesScreenshot) driver;
						File src=ss.getScreenshotAs(OutputType.FILE);
						File des= new File("./ParaBankFuctionalities.png");
						File des1= new File("./ParaBank_Defect.png");
						FileUtils.copyFileToDirectory(src, des);
						FileUtils.copyFileToDirectory(src, des1);
						Thread.sleep(2000);
						 driver.close();
						 
						 
						
						
			 


}
		
	

}

